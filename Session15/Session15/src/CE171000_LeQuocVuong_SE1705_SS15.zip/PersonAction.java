interface PersonAction {
    public void NhapTT();

    public void InTT();
}