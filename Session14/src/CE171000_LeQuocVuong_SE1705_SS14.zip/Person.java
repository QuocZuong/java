abstract class Person {
    String Maso;
    String HoTen;
    String Email;

    // An abstract function
    abstract void NhapTT();

    abstract void InTT();

}