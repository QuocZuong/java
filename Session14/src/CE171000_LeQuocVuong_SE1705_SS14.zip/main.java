public class main {
    public static void main(String[] args) throws Exception {
        employeeManagement employeeManagement = new employeeManagement();
        employeeManagement.menu();
    }
}
