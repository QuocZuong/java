public class main {

    public static void main(String[] args) {
        bubble bb = new bubble();
        bb.input();
        bb.sort();
        System.out.println("Danh sach sau khi sap xep bubble sort:");
        bb.print();
    }
}