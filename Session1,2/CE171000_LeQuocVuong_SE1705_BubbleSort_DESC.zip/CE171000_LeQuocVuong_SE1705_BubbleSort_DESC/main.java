public class main {

    public static void main(String[] args) {
        bubble bb = new bubble();
        bb.input();
        bb.sort();
        bb.print();

    }
}