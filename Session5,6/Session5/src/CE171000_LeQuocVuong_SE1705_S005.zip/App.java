public class App {
    public static void main(String[] args) throws Exception {
        date call = new date();
        call.input();
    }
}
