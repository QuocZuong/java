public class App {
    public static void main(String[] args) throws Exception {
        convert cv = new convert();
        cv.input();
    }
}
