import java.util.Scanner;

public class convert {
    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("CHUONG TRINH QUI DOI CO SO");
        System.out.println("1. Doi tu thap phan sang thap luc phan");
        System.out.println("2. Doi tu thap luc phan sang thap phan");
        System.out.println("3. Thoat");
        System.out.println("---------------------------------");

        while (true) {
            System.out.print("Ban chon: ");
            try {
                int choice = Integer.parseInt(sc.nextLine());
                if (choice == 1) {
                    decimalToHexa();
                    System.out.println("---------------------------------");

                } else if (choice == 2) {
                    hexaToDecimal();
                    System.out.println("---------------------------------");

                } else if (choice == 3) {
                    System.out.println("TAM BIET!!!");
                    System.exit(0);
                }
            } catch (Exception e) {
                System.out.println("Vui long chon so 1-3");
            }
        }
    }

    public void decimalToHexa() {
        Scanner sc = new Scanner(System.in);
        int decimal = 0;
        String hexa = "";
        try {
            System.out.print("So thap phan: ");
            decimal = Integer.parseInt(sc.nextLine());
            while (decimal != 0) {
                int remainder = decimal % 16;
                if (remainder < 10) {
                    hexa = remainder + hexa;
                } else {
                    hexa = (char) (remainder + 55) + hexa;
                }
                decimal = decimal / 16;
            }
            System.out.println("Thap luc phan: " + hexa);
        } catch (Exception e) {
            System.out.println("So thap phan khong hop le");

        }

    }

    public void hexaToDecimal() {
        Scanner sc = new Scanner(System.in);
        int decimal = 0, power = 0;
        System.out.print("So thap luc phan: ");
        String hexa = sc.nextLine();
        for (int i = hexa.length() - 1; i >= 0; i--) {
            char c = hexa.charAt(i);
            if (c >= '0' && c <= '9') {
                decimal += (c - '0') * Math.pow(16, power);
            } else if (c >= 'A' && c <= 'F') {
                decimal += (c - 55) * Math.pow(16, power);
            } else if (c >= 'a' && c <= 'f') {
                decimal += (c - 87) * Math.pow(16, power);
            }
            power++;
        }
        System.out.println("So thap phan: " + decimal);
    }
}