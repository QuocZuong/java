public class main {
    public static void main(String[] args) {
        quizManagement call = new quizManagement();
        call.menu();
    }
}
