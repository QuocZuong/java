public class main {
    public static void main(String[] args) {
        dictionaryManagement call = new dictionaryManagement();
        call.menu();
    }
}
