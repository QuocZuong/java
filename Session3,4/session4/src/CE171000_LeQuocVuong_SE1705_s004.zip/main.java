
public class main {
    public static void main(String[] args) {
        separateLetter sb = new separateLetter();
        sb.input();
    }

}
