public class main {
    public static void main(String[] args) throws Exception {
        bubbleSort bb = new bubbleSort();
        bb.input();
        bb.sort();
        bb.output();
        bb.binarySearch();
    }
}
