public class main {
    public static void main(String[] args) {
        teacherManagement call = new teacherManagement();
        call.menu();
    }
}
